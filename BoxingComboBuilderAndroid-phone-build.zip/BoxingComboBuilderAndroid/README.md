# 복싱 콤보 빌더 — 휴대폰만으로 APK 빌드하기

이 프로젝트는 기존 HTML 복싱 콤보 빌더를 Android WebView 앱으로 감싼 Android Studio 프로젝트입니다.

## PC 없이 빌드하는 방법 (GitHub Actions)
1. 휴대폰 브라우저에서 GitHub 계정을 만들거나 로그인합니다.
2. GitHub에서 새 Repository를 만듭니다. 예: `boxing-combo-builder`
3. 이 ZIP을 휴대폰에서 압축 해제한 뒤, GitHub 저장소에 프로젝트 파일과 폴더를 업로드합니다.
   - `.github/workflows/build-apk.yml` 파일도 반드시 포함해야 합니다.
   - ZIP 파일 자체만 저장소에 올리면 안 됩니다. 압축을 풀고 안의 파일들을 올립니다.
4. 저장소의 **Actions** 탭을 엽니다.
5. 왼쪽에서 **Build Android APK**를 선택하고 **Run workflow**를 누릅니다.
6. 빌드가 끝나면 해당 실행 기록 아래 **Artifacts**에서 `boxing-combo-builder-apk`를 다운로드합니다.
7. 받은 ZIP을 풀면 `app-debug.apk`가 있습니다. 파일을 눌러 설치합니다.
8. Android에서 설치 권한 안내가 나오면, 다운로드에 사용한 브라우저/파일 앱에 대해 해당 설치 권한을 허용합니다.

## 포함 기능
- 원본 복싱 콤보 빌더 화면 및 기술 데이터
- 앱 내부 로컬 저장공간에 기록 보관
- 백업 내보내기용 Android 파일 저장 창
- 백업 가져오기용 Android 파일 선택 창
- GitHub Actions로 클라우드 APK 빌드

## 참고
- GitHub 계정과 인터넷 연결이 필요합니다.
- APK는 디버그 서명 빌드입니다. 개인 휴대폰에 설치해 사용하는 용도입니다.
- 기록은 앱 내부 저장공간에 저장됩니다. 앱 삭제 시 기록이 함께 삭제될 수 있으므로 백업 기능을 이용하세요.
